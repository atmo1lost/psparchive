====================
BatteryWarning v1.0
====================

Author: Zooner_MT

=====================================================================================

BatteryWarning plugin, will warn you when your PSP battery is running low on charge.

=====================================================================================

Place "�batterywarning.prx"� into "ms0:/seplugins/" folder.

(PSP)
ms0:/seplugins/batterywarning.prx 1

(PSP Go)
ef0:/seplugins/batterywarning.prx 1

=====================================================================================

LCFW/CFW/HEN Firmware: 6.20 to 6.60 support

=====================================================================================

Version:

v1.0�
� First release

=====================================================================================

LibMenu	by maxem

=====================================================================================