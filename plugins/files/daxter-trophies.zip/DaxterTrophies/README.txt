Put PSP_TROPHIES in ms0:/PSP/GAME
Put daxter_trophies.prx in seplugins, enable it only for game to avoid any bugs.
